from subject import Subject

class RealSubject(Subject):
    def perform_action(self) -> None:
        print("Fazendo ação confidencial...")
