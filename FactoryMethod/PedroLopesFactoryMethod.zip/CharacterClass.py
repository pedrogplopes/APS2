from CharacterInterface import Character

class Adept(Character):
    def display(self):
        print("Adept character class.")

class Soldier(Character):
    def display(self):
        print("Soldier character class.")

class Engineer(Character):
    def display(self):
        print("Engineer character class.")

class Sentinel(Character):
    def display(self):
        print("Sentinel character class.")

class Vanguard(Character):
    def display(self):
        print("Vanguard character class.")

class Infiltrator(Character):
    def display(self):
        print("Infiltrator character class.")